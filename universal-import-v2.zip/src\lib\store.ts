// ===== 全局状态管理（localStorage 持久化） =====
import type { ParseRule, ParsedOrder } from "./types";

const STORAGE_KEYS = {
  RULES: "ui_v2_rules",
  ORDERS: "ui_v2_orders",
} as const;

// ----- 规则管理 -----
export function getRules(): ParseRule[] {
  if (typeof window === "undefined") return [];
  try {
    const data = localStorage.getItem(STORAGE_KEYS.RULES);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function saveRule(rule: ParseRule): void {
  const rules = getRules();
  const idx = rules.findIndex((r) => r.id === rule.id);
  if (idx >= 0) {
    rules[idx] = { ...rule, updatedAt: new Date().toISOString() };
  } else {
    rules.push(rule);
  }
  localStorage.setItem(STORAGE_KEYS.RULES, JSON.stringify(rules));
}

export function deleteRule(id: string): void {
  const rules = getRules().filter((r) => r.id !== id);
  localStorage.setItem(STORAGE_KEYS.RULES, JSON.stringify(rules));
}

export function getRule(id: string): ParseRule | undefined {
  return getRules().find((r) => r.id === id);
}

// ----- 运单管理 -----
export function getOrders(): ParsedOrder[] {
  if (typeof window === "undefined") return [];
  try {
    const data = localStorage.getItem(STORAGE_KEYS.ORDERS);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function saveOrders(orders: ParsedOrder[]): void {
  const existing = getOrders();
  const combined = [...existing, ...orders];
  localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(combined));
}

export function clearCurrentOrders(): void {
  localStorage.removeItem("ui_v2_current_orders");
}

export function getCurrentOrders(): ParsedOrder[] {
  if (typeof window === "undefined") return [];
  try {
    const data = localStorage.getItem("ui_v2_current_orders");
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function setCurrentOrders(orders: ParsedOrder[]): void {
  localStorage.setItem("ui_v2_current_orders", JSON.stringify(orders));
}

// ----- ID 生成 -----
export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substring(2, 8);
}
