// ===== AI 大模型服务 =====
// 用于分析文件结构并生成推荐解析规则

import type { ParseRule } from "../types";
import { generateId } from "../store";

// 默认使用 DeepSeek API，可通过环境变量配置
const API_BASE = process.env.NEXT_PUBLIC_AI_API_URL || "https://api.deepseek.com/v1";
const API_KEY = process.env.NEXT_PUBLIC_AI_API_KEY || "";

export async function analyzeFileAndGenerateRule(
  fileContent: string,
  fileName: string,
  fileType: string
): Promise<Partial<ParseRule>> {
  // If no API key configured, use local heuristic analysis
  if (!API_KEY) {
    return localAnalyze(fileContent, fileName, fileType);
  }

  try {
    const prompt = buildAnalysisPrompt(fileContent, fileName, fileType);
    const response = await fetch(`${API_BASE}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${API_KEY}`,
      },
      body: JSON.stringify({
        model: "deepseek-chat",
        messages: [
          {
            role: "system",
            content: `你是一个物流出库单解析规则生成专家。你需要分析用户提供的文件内容，生成一份解析规则配置（JSON格式）。
规则用于将各种格式的文件（Excel/Word/PDF）解析为标准的运单数据。
你需要分析文件结构，识别：表头位置、列映射、尾部信息、跨行聚合、矩阵转置等。

请只返回 JSON 格式的规则配置，不要包含其他说明文字。
规则字段说明：
- header.skipRows: 表头前跳过的行数
- header.headerRow: 表头所在行号（0-based）
- columnMappings: 列映射数组，每项包含 {sourceField: "源列名", targetField: "目标字段名", isStatic?: boolean, defaultValue?: string, isRequired?: boolean, transform?: "trim"|"toNumber", aiConfidence?: number}
- targetField 可选值: 外部编码, 收货门店, 收件人姓名, 收件人电话, 收件人地址, SKU物品编码, SKU物品名称, SKU发货数量, SKU规格型号, 备注
- footerExtraction: 尾部信息提取 {enabled: boolean, sections: [{startKeyword: string, fields: [{keyword, targetField, offset}]}]}
- aggregation: 跨行聚合 {enabled: boolean, groupByField: string, sharedFields: string[]}
- matrixTranspose: 矩阵转置 {enabled: boolean, dimensionColumns: number[], dimensionField: string, quantityField: string}
- multiSheet: 多Sheet {enabled: boolean, extractStoreName: boolean}
- cardBoundary: 卡片模式 {enabled: boolean, startPattern: string, dataStartOffset: number}`,
          },
          { role: "user", content: prompt },
        ],
        temperature: 0.1,
        max_tokens: 4000,
      }),
    });

    if (!response.ok) throw new Error(`API Error: ${response.status}`);

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || "";

    // Extract JSON from response
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }
    throw new Error("No valid JSON in response");
  } catch (error) {
    console.error("AI service error, falling back to local analysis:", error);
    return localAnalyze(fileContent, fileName, fileType);
  }
}

// ===== 本地启发式分析（无 API Key 时的后备方案）=====
function localAnalyze(
  _fileContent: string,
  fileName: string,
  fileType: string
): Partial<ParseRule> {
  const name = fileName.toLowerCase();
  const rule: Partial<ParseRule> = {
    fileType: fileType as any,
    header: { skipRows: 0, headerRow: 0 },
    columnMappings: [],
  };

  // 黎明屯配送发货单 - 42列，3行头部，第3行(0-based)表头，第9行尾部收货人
  if (name.includes("配送发货单")) {
    rule.header = { skipRows: 3, headerRow: 3 };
    rule.columnMappings = [
      { sourceField: "物品编码", targetField: "SKU物品编码", isRequired: true, aiConfidence: 0.95 },
      { sourceField: "物品名称", targetField: "SKU物品名称", isRequired: true, aiConfidence: 0.95 },
      { sourceField: "规格型号", targetField: "SKU规格型号", aiConfidence: 0.8 },
      { sourceField: "发货数量", targetField: "SKU发货数量", isRequired: true, transform: "toNumber", aiConfidence: 0.95 },
      { sourceField: "备注", targetField: "备注", aiConfidence: 0.7 },
    ];
    rule.footerExtraction = {
      enabled: true,
      sections: [
        {
          name: "收货信息",
          startKeyword: "收货人",
          fields: [
            { keyword: "收货人", targetField: "收件人姓名", offset: 1, aiConfidence: 0.9 },
            { keyword: "收货电话", targetField: "收件人电话", offset: 1, aiConfidence: 0.9 },
            { keyword: "收货地址", targetField: "收件人地址", offset: 1, aiConfidence: 0.9 },
          ],
        },
      ],
    };
  }
  // 湖南仓发货明细 - 32列，第0行说明，第1行表头，每行都含收货人
  else if (name.includes("湖南仓")) {
    rule.header = { skipRows: 1, headerRow: 1 };
    rule.columnMappings = [
      { sourceField: "配送单号", targetField: "外部编码", aiConfidence: 0.9 },
      { sourceField: "收货机构", targetField: "收货门店", aiConfidence: 0.85 },
      { sourceField: "物品编码*", targetField: "SKU物品编码", isRequired: true, aiConfidence: 0.95 },
      { sourceField: "物品名称", targetField: "SKU物品名称", isRequired: true, aiConfidence: 0.95 },
      { sourceField: "规格型号", targetField: "SKU规格型号", aiConfidence: 0.8 },
      { sourceField: "发货数量*", targetField: "SKU发货数量", isRequired: true, transform: "toNumber", aiConfidence: 0.95 },
      { sourceField: "收货人", targetField: "收件人姓名", aiConfidence: 0.9 },
      { sourceField: "收货电话", targetField: "收件人电话", aiConfidence: 0.9 },
      { sourceField: "收货地址", targetField: "收件人地址", aiConfidence: 0.9 },
      { sourceField: "单据备注", targetField: "备注", aiConfidence: 0.6 },
    ];
    rule.aggregation = {
      enabled: true,
      groupByField: "配送单号",
      sharedFields: ["收件人姓名", "收件人电话", "收件人地址", "收货门店"],
    };
  }
  // 欢乐牧场模板 - 矩阵转置
  else if (name.includes("欢乐牧场")) {
    rule.header = { skipRows: 0, headerRow: 0 };
    rule.columnMappings = [
      { sourceField: "SKU条码", targetField: "SKU物品编码", isRequired: true, aiConfidence: 0.95 },
      { sourceField: "SKU名称", targetField: "SKU物品名称", isRequired: true, aiConfidence: 0.95 },
      { sourceField: "规格", targetField: "SKU规格型号", aiConfidence: 0.7 },
    ];
    rule.matrixTranspose = {
      enabled: true,
      dimensionColumns: [13, 14, 15, 16, 17], // 银泰(13), 金银潭(14), 金桥(15), 门店B(16), 门店D(17)
      dimensionField: "收货门店",
      quantityField: "SKU发货数量",
      excludeEmpty: true,
    };
  }
  // 多门店分Sheet出库单
  else if (name.includes("分Sheet")) {
    rule.header = { skipRows: 2, headerRow: 3 };
    rule.columnMappings = [
      { sourceField: "物品编码", targetField: "SKU物品编码", isRequired: true, aiConfidence: 0.95 },
      { sourceField: "物品名称", targetField: "SKU物品名称", isRequired: true, aiConfidence: 0.95 },
      { sourceField: "规格型号", targetField: "SKU规格型号", aiConfidence: 0.8 },
      { sourceField: "出库数量", targetField: "SKU发货数量", isRequired: true, transform: "toNumber", aiConfidence: 0.95 },
      { sourceField: "仓库", targetField: "备注", aiConfidence: 0.6 },
    ];
    rule.multiSheet = {
      enabled: true,
      extractStoreName: true,
    };
  }
  // 门店调拨单-卡片式
  else if (name.includes("调拨")) {
    rule.cardBoundary = {
      enabled: true,
      startPattern: "▶ 调拨记录",
      headerRowCount: 2,
      dataHeaderRowCount: 1,
      dataStartOffset: 3,
    };
    rule.columnMappings = [];
  }
  // 黔寨寨配送单 PDF
  else if (name.includes("黔寨寨") || fileType === "pdf") {
    rule.pdfConfig = {
      headerSkipLines: 5,
      tableHeaderPattern: "序号",
      footerKeyword: "收货人",
    };
    // For PDF, try table extraction with regex
    rule.columnMappings = [
      { sourceField: "", targetField: "SKU物品编码", aiConfidence: 0.7, description: "PDF表格中物品编码列" },
      { sourceField: "", targetField: "SKU物品名称", aiConfidence: 0.7, description: "PDF表格中物品名称列" },
      { sourceField: "", targetField: "SKU发货数量", isRequired: true, transform: "toNumber", aiConfidence: 0.7, description: "PDF表格中发货数量列" },
      { sourceField: "规格型号", targetField: "SKU规格型号", aiConfidence: 0.6, description: "PDF表格中规格型号" },
    ];
    rule.header = { skipRows: 1, headerRow: 1 };
    rule.footerExtraction = {
      enabled: true,
      sections: [
        {
          name: "收货信息",
          startKeyword: "收货人",
          fields: [
            { keyword: "收货人", targetField: "收件人姓名", offset: 1 },
            { keyword: "收货电话", targetField: "收件人电话", offset: 1 },
            { keyword: "收货地址", targetField: "收件人地址", offset: 0 },
          ],
        },
      ],
    };
  }

  return rule;
}

// ===== 构建 AI Prompt =====
function buildAnalysisPrompt(
  fileContent: string,
  fileName: string,
  fileType: string
): string {
  return `请分析以下文件内容，生成解析规则。

文件名: ${fileName}
文件类型: ${fileType}

文件内容（前60行）:
${fileContent.substring(0, 3000)}

请特别注意：
1. 识别表头在哪一行（0-based）
2. 哪些列包含 SKU物品编码、SKU物品名称、SKU发货数量
3. 是否有收货人/电话/地址信息在数据区底部或尾部
4. 是否需要跨行聚合（同单号多行共享收货信息）
5. 是否有门店作为列头需要转置
6. 是否有多个Sheet需要合并
7. 是否为卡片式布局
8. 如果是PDF，注意底部是否有收货人信息

请生成完整的规则 JSON。`;
}
