"use client";

import { useState, useEffect, useMemo } from "react";
import { getOrders } from "@/lib/store";
import type { ParsedOrder } from "@/lib/types";
import { formatDate } from "@/lib/utils";

const PAGE_SIZE = 20;

export default function HistoryPage() {
  const [orders, setOrders] = useState<ParsedOrder[]>([]);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(0);
  const [selectedOrder, setSelectedOrder] = useState<ParsedOrder | null>(null);

  useEffect(() => {
    setOrders(getOrders().reverse());
  }, []);

  const filtered = useMemo(() => {
    if (!search.trim()) return orders;
    const q = search.toLowerCase();
    return orders.filter((o) =>
      (o.外部编码 || "").toLowerCase().includes(q) ||
      (o.收件人姓名 || "").toLowerCase().includes(q) ||
      (o.收货门店 || "").toLowerCase().includes(q) ||
      (o.SKU物品编码 || "").toLowerCase().includes(q) ||
      (o.SKU物品名称 || "").toLowerCase().includes(q)
    );
  }, [orders, search]);

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const paged = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  return (
    <div className="fade-in">
      <div style={{ marginBottom: 20 }}>
        <h1 style={{ fontSize: 22, fontWeight: 700 }}>已导入运单</h1>
        <p style={{ fontSize: 13, color: "var(--text-secondary)", marginTop: 4 }}>
          共 {orders.length} 条运单记录
        </p>
      </div>

      {/* Search */}
      <div style={{ marginBottom: 16 }}>
        <input
          className="input"
          style={{ maxWidth: 400 }}
          placeholder="搜索外部编码、收货人、门店、物品..."
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(0); }}
        />
      </div>

      {/* Orders Table */}
      <div className="card">
        <div className="table-wrapper" style={{ maxHeight: "none" }}>
          <table className="data-table">
            <thead>
              <tr>
                <th style={{ width: 40 }}>#</th>
                <th>外部编码</th>
                <th>收货门店</th>
                <th>收件人</th>
                <th>电话</th>
                <th>SKU编码</th>
                <th>SKU名称</th>
                <th>数量</th>
                <th>规格</th>
                <th style={{ width: 100 }}>操作</th>
              </tr>
            </thead>
            <tbody>
              {paged.length === 0 ? (
                <tr>
                  <td colSpan={10} style={{ textAlign: "center", padding: 40, color: "var(--text-secondary)" }}>
                    {search ? "未找到匹配记录" : "暂无运单数据，请先导入"}
                  </td>
                </tr>
              ) : (
                paged.map((order, idx) => (
                  <tr key={page * PAGE_SIZE + idx}>
                    <td style={{ fontSize: 12, color: "var(--text-secondary)" }}>{page * PAGE_SIZE + idx + 1}</td>
                    <td style={{ fontWeight: 500 }}>{order.外部编码 || "-"}</td>
                    <td>{order.收货门店 || "-"}</td>
                    <td>{order.收件人姓名 || "-"}</td>
                    <td>{order.收件人电话 || "-"}</td>
                    <td style={{ fontSize: 12, fontFamily: "monospace" }}>{order.SKU物品编码}</td>
                    <td>{order.SKU物品名称}</td>
                    <td style={{ textAlign: "right" }}>{order.SKU发货数量}</td>
                    <td style={{ fontSize: 12, color: "var(--text-secondary)" }}>{order.SKU规格型号 || "-"}</td>
                    <td>
                      <button className="btn btn-ghost btn-sm" onClick={() => setSelectedOrder(order)}>
                        详情
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div style={{ padding: "12px 16px", display: "flex", justifyContent: "center", alignItems: "center", gap: 8, borderTop: "1px solid var(--border)" }}>
            <button className="btn btn-ghost btn-sm" disabled={page === 0} onClick={() => setPage(page - 1)}>
              上一页
            </button>
            <span style={{ fontSize: 13, color: "var(--text-secondary)" }}>
              第 {page + 1} / {totalPages} 页
            </span>
            <button className="btn btn-ghost btn-sm" disabled={page >= totalPages - 1} onClick={() => setPage(page + 1)}>
              下一页
            </button>
          </div>
        )}
      </div>

      {/* Detail Modal */}
      {selectedOrder && (
        <div className="modal-overlay" onClick={() => setSelectedOrder(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 500 }}>
            <div className="modal-header">
              <h3 style={{ fontSize: 16, fontWeight: 600 }}>运单详情</h3>
              <button className="btn btn-ghost btn-sm" onClick={() => setSelectedOrder(null)}>✕</button>
            </div>
            <div className="modal-body">
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                {[
                  ["外部编码", selectedOrder.外部编码],
                  ["收货门店", selectedOrder.收货门店],
                  ["收件人姓名", selectedOrder.收件人姓名],
                  ["收件人电话", selectedOrder.收件人电话],
                  ["收件人地址", selectedOrder.收件人地址],
                  ["SKU物品编码", selectedOrder.SKU物品编码],
                  ["SKU物品名称", selectedOrder.SKU物品名称],
                  ["SKU发货数量", String(selectedOrder.SKU发货数量)],
                  ["SKU规格型号", selectedOrder.SKU规格型号],
                  ["备注", selectedOrder.备注],
                ].map(([label, value]) => (
                  <div key={label}>
                    <div style={{ fontSize: 12, color: "var(--text-secondary)", marginBottom: 2 }}>{label}</div>
                    <div style={{ fontSize: 14, fontWeight: 500 }}>{value || "-"}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setSelectedOrder(null)}>关闭</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
